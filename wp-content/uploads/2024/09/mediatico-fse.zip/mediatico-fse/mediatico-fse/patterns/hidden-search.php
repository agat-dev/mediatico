<?php
/**
 * Title: Search
 * Slug: mediatico-fse/hidden-search
 * Inserter: no
 */
?>

<!-- wp:search {"label":"<?php echo esc_attr_x( 'Search', 'search form label', 'mediatico-fse' ); ?>","showLabel":false,"buttonText":"<?php echo esc_attr_x( 'Search', 'search button text', 'mediatico-fse' ); ?>","fontSize":"medium"} /-->
