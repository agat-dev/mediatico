<?php
/**
 * Title: No results
 * Slug: mediatico-fse/hidden-no-results
 * Inserter: no
 */
?>
<!-- wp:paragraph -->
<p><?php echo esc_html_x( 'No posts were found.', 'Message explaining that there are no results returned from a search', 'mediatico-fse' ); ?></p>
<!-- /wp:paragraph -->
